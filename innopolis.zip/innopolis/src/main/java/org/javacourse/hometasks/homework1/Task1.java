package org.javacourse.hometasks.homework1;


public class Task1 {
    public static void main(String[] args) {

        for (int i = 1; i <= 4; i++) {
            System.out.print(i + "   ");
        }
    }
}